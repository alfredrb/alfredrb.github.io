# /etc/profile.d/sureflow-menu.sh
# Drop an admin straight into the controller menu on console or SSH login.
# Interactive shells only — a non-interactive session (scp, rsync, remote command)
# must never be swallowed by whiptail.
case "$-" in
  *i*)
    if [ -z "${SUREFLOW_MENU_SHOWN:-}" ] && [ -x /usr/local/bin/sureflow-menu ]; then
      export SUREFLOW_MENU_SHOWN=1
      /usr/local/bin/sureflow-menu
    fi
    ;;
esac
