SureFlow lane agent — staged, not installed on this box
=======================================================

These files belong INSIDE the diskless lane root, not on the controller. The tarball
carries them so building a lane root needs no second download.

  sureflow-lane-agent          -> <root>/usr/local/bin/sureflow-lane-agent   (mode 755)
  sureflow-lane-agent.service  -> <root>/etc/systemd/system/                 (mode 644)

The agent is what makes the controller menu's Lanes screen work at all: lanes sit on the
isolated PXE VLAN and cannot be reached inbound, so the agent polls the relay outbound
for a queued reboot and reports itself as seen. A root without the agent shows up as
"never seen" in the Lanes table and cannot be rebooted remotely.

Build steps (run on the controller, ROOT = the lane root you are building):

# Install the lane agent into the diskless image (run on the PXE CONTROLLER).
# Node is needed inside the image — it is a ~30MB addition to the root.

# Set ROOT and PROVE it before chrooting. An unset ROOT makes the next command
# collapse to "chroot apt-get ...", which fails with the confusing
# "cannot change root directory to 'apt-get'". ROOT also does NOT survive a new
# shell or a sudo -i, so re-run this line in every session.
ROOT=/srv/nfs/sureflow-legacy
ls -d "$ROOT" || { echo "ROOT is wrong or unset — stop here"; }

sudo chroot "$ROOT" /bin/bash -eux <<'CHROOT'
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y --no-install-recommends nodejs
  node --version   # must be >= 18 for the built-in fetch the agent uses
CHROOT

# Paste the agent and its unit in (see the two blocks above), then:
sudo chmod +x "$ROOT/usr/local/bin/sureflow-lane-agent"
sudo chroot "$ROOT" systemctl enable sureflow-lane-agent

# Republish the boot files so the lanes pick up the new root.
sudo cp "$ROOT"/boot/vmlinuz-*    /srv/tftp/debian-legacy/vmlinuz
sudo cp "$ROOT"/boot/initrd.img-* /srv/tftp/debian-legacy/initrd.img

