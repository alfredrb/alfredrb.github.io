SureFlow Store Controller — installer bundle
Pre-seeded for store 001 (Supermart)
Generated 2026-08-27T02:27:23.781Z from https://preview-sandbox--6a42d5b340732607e237e3b7.base44.app

WHAT THIS IS
  A fresh Debian 12 box becomes a COMBINED store controller: PXE/TFTP + the NFS lane
  roots on the isolated boot VLAN 40, and the SureFlow Local Relay on the routed backend
  VLAN 25. Both interfaces must already be up and addressed before you start — the
  backend side is the only one with an internet route, and the wizard fetches packages
  and clones the relay through it.

RUN IT
  tar xzf sureflow-controller-*.tar.gz
  cd sureflow-controller-*
  sudo ./install

  ./install copies the wizard, the console menu and its login hook into place, stages the
  lane agent under /srv/sureflow/lane-agent, and then runs the wizard. Re-running is safe:
  saved answers come back as the defaults.

CONTENTS
  install                        this wrapper
  sureflow-controller-install    the guided wizard (installs to /usr/local/sbin)
  sureflow-menu                  the console menu (installs to /usr/local/bin)
  sureflow-menu.sh               login hook (installs to /etc/profile.d)
  sureflow-build-lane-image      the lane image builder (installs to /usr/local/sbin)
  sureflow-fetch-splash-assets   stages the boot splash PNGs (installs to /usr/local/sbin,
                                 and ./install runs it once so the first image is branded)
  lane-agent/                    for the diskless lane root, NOT this box — see its README
  controller.conf                pre-seeded answers for this store

THIS STORE'S VALUES
  Store number  : 001   (Supermart)
  Role          : standalone
  
  VLAN 40 (PXE, isolated — serves lanes)
    This box IP : 10.0.40.10
    PXE subnet  : 10.0.40.0/24
    PXE VIP     : same as this box (standalone)
  
  VLAN 25 (backend, internet-routed — relay, cloud, printers)
    This box IP : <set the VIP on the Redundancy card>
    Backend VIP : <set the VIP on the Redundancy card>
  
  Relay URL     : http://<backend vip>:3000
  Relay API key : generate on this store's Relay Ops card, then paste at the prompt
  
  Standalone: the wizard points both VIP prompts at this box's own addresses, so keepalived is skipped entirely and the relay unit is enabled directly. Moving to a pair later is just a re-run with role=primary.
  
  Remember: the cloud and the Infrastructure Command Center poll the BACKEND address.
  A store whose relay URL points at the PXE address will always read as unreachable.
LANE IMAGES — THE WIZARD CAN BUILD THEM FOR YOU
  Near the end the wizard asks: build the lane images now? (both / legacy / modern / skip)
  A build is bootable end to end and needs no manual image editing afterwards:
    1. Debian base root + the kiosk package set, initramfs set up for NFS root
    2. the fleet layer — sureflow-kiosk, sureflow-boot-env, the serial and printer
       bridges, and the lane agent staged from lane-agent/ in this bundle
    3. this store's HardwareLibrary profiles, pulled from the cloud with the relay API
       key: scancode maps, touch calibration, extra modules and packages

  ALLOW 15-30 MINUTES PER VARIANT. It downloads a full Debian root over the BACKEND
  VLAN, so that side must have an internet route. Only build the variants this store
  actually has.

  Choose 'skip' on a cutover night where an existing root can be rsynced from the old
  controller — faster, and byte-identical to the lanes that were already working. The
  builder is installed either way and is re-runnable at any time:

    sudo sureflow-build-lane-image both       # or: legacy | modern
    cat /srv/sureflow/.lane-image-summary     # what was built, and any warnings

  or from the console menu: Lanes > Build a lane image. Re-running IS the fleet patch
  path — the root is replaced rather than edited, so builds stay reproducible, and lanes
  pick up the new root on their next reboot.

  No relay API key yet, or no cloud route? The build still produces a BOOTABLE image and
  says on its summary that the hardware profiles were skipped. Re-run once the route is
  up to layer them in.

AFTER THE WIZARD
  * Set this store's relay URL in the Infrastructure Command Center to the BACKEND
    address on port 3000 — never the PXE address, which the cloud cannot reach.
  * Generate each lane's PXE entry on the Registers page (open a register, press PXE).
    These are keyed to the terminal's MAC, so the builder never creates them.
  * PXE boot one lane and confirm it comes up as the right register.
  * Log out and back in for the console menu.
